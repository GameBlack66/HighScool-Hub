---
name: High School Hub
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#6b38d4'
  on-secondary: '#ffffff'
  secondary-container: '#8455ef'
  on-secondary-container: '#fffbff'
  tertiary: '#982669'
  on-tertiary: '#ffffff'
  tertiary-container: '#b74082'
  on-tertiary-container: '#ffecf1'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#ffd8e7'
  tertiary-fixed-dim: '#ffafd3'
  on-tertiary-fixed: '#3d0026'
  on-tertiary-fixed-variant: '#85145a'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin: 24px
---

## Brand & Style

The design system is engineered for a high school demographic, prioritizing energy, clarity, and a "digital-native" aesthetic. The brand personality is optimistic and high-tempo, balancing the functional requirements of an information hub with the expressive nature of an entertainment platform.

The visual style is **Modern / Corporate-Vibrant**, utilizing clean layouts paired with high-saturation accent colors. It avoids the clutter of traditional "youth" marketing in favor of a sophisticated, app-like experience that treats students as mature users while maintaining a playful edge through generous curves and dynamic typography.

## Colors

The palette is anchored by a **Bright Blue** primary and an **Energetic Purple** secondary. These two colors should be used to drive the core UI actions and primary brand moments. 

- **Primary (Blue):** Used for main CTAs, active states, and essential navigation.
- **Secondary (Purple):** Used for entertainment-specific features, badges, and secondary highlights.
- **Tertiary (Soft Pink):** Employed sparingly for accents, notifications, or "new" indicators to add warmth without reaching neon levels.
- **Neutral:** A deep navy-charcoal is used for text to ensure high contrast against a primarily white and light-gray background (#F8FAFC). 

Color application should follow a 60-30-10 rule to maintain a "clean" feel, ensuring the white space remains the dominant "color" to prevent cognitive overload.

## Typography

This design system utilizes a dual-font strategy to balance impact with readability.

**Montserrat** is the display face. It should be used for all headings. The "ExtraBold" and "Bold" weights are preferred to create a strong visual hierarchy. For the largest headlines, a slight negative letter-spacing is applied to create a tighter, more modern "poster" effect.

**Plus Jakarta Sans** is the functional face. It provides a friendly, slightly rounded geometric feel that complements the display type while remaining highly legible for long-form news content and data-heavy info cards. 

For mobile, headlines scale down significantly to prevent awkward word-breaks, while body text remains large (16px minimum) to cater to on-the-go reading.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a 12-column structure for desktop and a 4-column structure for mobile. 

- **Containers:** All content is housed within responsive containers with a maximum width of 1280px.
- **Rhythm:** A base-8 unit drives all spacing. Elements should typically be separated by `md` (24px) or `lg` (48px) units to maintain an open, breathable feel.
- **Card Spacing:** Inside cards, use `sm` (12px) for internal element grouping and `md` (24px) for padding between the card edge and content.
- **Mobile Reflow:** On mobile, side-by-side cards (e.g., in a news feed) should reflow into a single-column vertical stack to maximize touch targets.

## Elevation & Depth

Visual hierarchy is achieved through a combination of **Tonal Layering** and **Ambient Shadows**.

1.  **Background (Level 0):** Pure White (#FFFFFF) or very light slate (#F8FAFC).
2.  **Surface (Level 1):** Cards and main containers use a white background with a very soft, diffused shadow. The shadow should have a large blur radius (24px+) and low opacity (5-8%), using a slight tint of the neutral dark navy rather than pure black.
3.  **Active/Hover (Level 2):** When interacting with cards or buttons, the shadow intensity increases and the element may lift slightly (Y-axis translation).
4.  **Floating (Level 3):** Modals and navigation menus use a more distinct shadow to separate them clearly from the content layers below.

Avoid heavy borders or harsh outlines. Use thin, 1px borders in a very light gray (#E2E8F0) only when content needs separation on a white background without adding shadow-based bulk.

## Shapes

The shape language is defined by **large, friendly radii**. 

- **Cards & Primary Containers:** Use `rounded-lg` (16px) as the standard. This creates a soft, approachable container that feels modern.
- **Buttons:** Primary buttons should use `rounded-xl` (24px) or be fully pill-shaped to differentiate them from static content cards.
- **Inputs:** Text fields and search bars follow the `rounded-lg` (16px) standard to match the card aesthetic.
- **Imagery:** Photos and thumbnails within cards should inherit the container's roundedness or use a slightly smaller radius (12px) to create a nested "frame" effect.

## Components

### Buttons
Primary buttons use the Bright Blue background with white text. They should have a "bounce" hover effect (slight scale-up) and a subtle shadow that grows on hover. The "Subscription CTA" should be distinct—consider a gradient from Primary Blue to Secondary Purple to make it the most vibrant element on the page.

### Cards
Cards are the primary vehicle for games and news. They feature a top-aligned image with a 16px corner radius, followed by a headline in Montserrat and a brief snippet in Plus Jakarta Sans. Footers within cards (e.g., "Read More" or "Play Now") should be clearly separated by whitespace, not necessarily a divider line.

### Chips & Tags
Use chips for categories (e.g., "Sports," "Gaming," "Prom"). These should have a light tinted background of the category color (e.g., 10% opacity Purple) with full-color bold text.

### Input Fields
Inputs should be tall (48px - 56px) with a light gray stroke. On focus, the stroke should transition to the Primary Blue with a 2px width.

### Lists
Lists should be "chunked"—each list item acts like a mini-card with its own hover state, rather than just text on a line. This maintains the tactile, modern feel of the design system.